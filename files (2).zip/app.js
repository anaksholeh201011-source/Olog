const promptInput = document.querySelector("#prompt");
const charCount = document.querySelector("#char-count");
const generateButton = document.querySelector("#generate-btn");
const styleSelect = document.querySelector("#style");
const ratioSelect = document.querySelector("#ratio");
const durationSelect = document.querySelector("#duration");
const preview = document.querySelector("#preview");
const previewLabel = document.querySelector("#preview-label");
const previewRatio = document.querySelector("#preview-ratio");
const previewDuration = document.querySelector("#preview-duration");
const result = document.querySelector("#result");
const toast = document.querySelector("#toast");

let demoConfig = {
  appName: "VIDEOLAB",
  demoMode: true,
  generationDelayMs: 1800
};

async function loadConfig() {
  try {
    const response = await fetch("./config.json");
    if (response.ok) demoConfig = { ...demoConfig, ...(await response.json()) };
  } catch {
    // Gunakan konfigurasi bawaan jika file dibuka tanpa server lokal.
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2800);
}

promptInput.addEventListener("input", () => {
  charCount.textContent = `${promptInput.value.length} / 500`;
});

ratioSelect.addEventListener("change", () => {
  previewRatio.textContent = ratioSelect.value;
});

durationSelect.addEventListener("change", () => {
  previewDuration.textContent = `${durationSelect.value} detik`;
});

generateButton.addEventListener("click", async () => {
  const prompt = promptInput.value.trim();

  if (!prompt) {
    promptInput.focus();
    showToast("Tulis ide video kamu terlebih dahulu.");
    return;
  }

  generateButton.disabled = true;
  generateButton.innerHTML = "<span>✦</span> Sedang menyiapkan demo...";
  result.classList.remove("is-ready");

  await new Promise((resolve) =>
    window.setTimeout(resolve, demoConfig.generationDelayMs)
  );

  preview.classList.add("is-generated");
  previewLabel.textContent = "PRATINJAU DEMO — BUKAN VIDEO AI";
  result.classList.add("is-ready");
  result.innerHTML = `
    <div class="result-icon">✦</div>
    <div>
      <strong>Demo siap dicoba!</strong>
      <p>Gaya ${escapeHtml(styleSelect.value)} · ${escapeHtml(ratioSelect.value)} · ${escapeHtml(durationSelect.value)} detik. Hubungkan backend AI untuk menghasilkan video sungguhan.</p>
    </div>
  `;

  generateButton.disabled = false;
  generateButton.innerHTML = '<span>✦</span> Buat video <span class="button-arrow">→</span>';
});

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

loadConfig();