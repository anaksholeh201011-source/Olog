export type VideoAspectRatio = "16:9" | "9:16" | "1:1";

export type VideoStyle =
  | "Sinematik"
  | "Animasi 3D"
  | "Anime"
  | "Dokumenter"
  | "Fantasi";

export interface VideoGenerationRequest {
  prompt: string;
  style: VideoStyle;
  aspectRatio: VideoAspectRatio;
  durationSeconds: 5 | 10 | 15;
}

export interface VideoGenerationResponse {
  jobId: string;
  status: "queued" | "processing" | "completed" | "failed";
  videoUrl?: string;
  error?: string;
}

export interface AppConfig {
  appName: string;
  demoMode: boolean;
  generationDelayMs: number;
}